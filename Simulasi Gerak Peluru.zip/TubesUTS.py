import math
def CalculationNum1(delT,V0,Angle):
    arrY=[0] 
    arrX=[0]
    X = 0
    Y = 0
    t = 0
    g = -9.806
    Angle = (35 / 180) * math.pi
    Vx = V0 * math.cos(Angle)
    Vy = V0 * math.sin(Angle)
    while (Y>=0):
        X = X + (Vx * delT)
        Y = Y + (Vy * delT)
        t+=delT
        Vy = Vy + (g * delT)
        arrX.append(X)
        arrY.append(Y)
    print("Hasil Perhitungan Numeric tanpa Hambatan Udara")
    print("Xmax Numeric 1 : ", max(arrX))
    print("Ymax Numeric 1 : ", max(arrY))
    print("Waktu total    : ",t,"\n")
CalculationNum1(0.01,50,35)

def CalculationAn1(delT,V0,Angle):
    arrY=[0]
    arrX=[0]
    X = 0
    Y = 0
    t = 0
    g = -9.806
    Angle = (35 / 180) * math.pi
    Vx = V0 * math.cos(Angle)
    Vy = V0 * math.sin(Angle)
    while (Y>=0):
        X = X + (Vx * delT)
        Y = Y + (Vy * delT) + (0.5 * g * pow(delT,2))
        t+=delT
        Vy = Vy + (g * delT)
        arrX.append(X)
        arrY.append(Y)
    print("Hasil Perhitungan Analitic tanpa Hambatan Udara")
    print("Xmax Analitic 2 : ", max(arrX))
    print("Ymax Analitic 2 : ", max(arrY))
    print("Waktu total    : ",t,"\n")
CalculationAn1(0.01, 50, 35)

# def CalculationAnalitic(V0, Angle):
#     g = -9.806
#     Angle = Angle = (35 / 180) * math.pi 
#     Ttot  = ( 2 * (V0 * math.sin(Angle)))/-g
#     Xmax = (V0 * math.cos(Angle)) * Ttot
#     Ymax = (math.pow(V0,2) * math.pow(math.sin(Angle),2))/(-2 * g)
#     print(Xmax)
#     print(Ymax)
# #CalculationAn1(50,35)

def CalculationNum2(m,D,delT,V0,Angle):
    arrY=[0]
    arrX=[0]
    X = 0
    Y = 0
    t = 0
    g = -9.806
    Angle = (35 / 180) * math.pi
    Vx = V0 * math.cos(Angle)
    Vy = V0 * math.sin(Angle)
    while (Y>=0):
        V = math.sqrt(math.pow(Vx,2) + math.pow(Vy,2))
        ax = -(D/m) * V * Vx
        ay = g - (D/m) * V * Vy
        t+=delT
        Vy = Vy + (ay * delT)
        Vx = Vx + (ax * delT)
        X = X + (Vx * delT)
        Y = Y + (Vy * delT)
        arrX.append(X)
        arrY.append(Y)
    print("Hasil Perhitungan Numeric dengan Hambatan Udara")
    print("Xmax Numeric 2 : ", max(arrX))
    print("Ymax Numeric 2 : ", max(arrY))
    print("Waktu total    : ",t,"\n")
CalculationNum2(0.15, 0.0013, 0.01, 50, 35)

def CalculationAn2(m,D,delT,V0,Angle):
    arrY=[0]
    arrX=[0]
    X = 0
    Y = 0
    t = 0
    g = -9.806
    Angle = (35 / 180) * math.pi
    Vx = V0 * math.cos(Angle)
    Vy = V0 * math.sin(Angle)
    while (Y>=0):
        V = math.sqrt(math.pow(Vx,2) + math.pow(Vy,2))
        ax = -(D/m) * V * Vx
        ay = g - (D/m) * V * Vy
        t+=delT
        Vy = Vy + (ay * delT)
        Vx = Vx + (ax * delT)
        X = X + (Vx * delT) + (0.5 * ax * pow(delT,2))
        Y = Y + (Vy * delT) + (0.5 * ay * pow(delT,2))
        arrX.append(X)
        arrY.append(Y)
    print("Hasil Perhitungan Analitic dengan Hambatan Udara")
    print("Xmax Analitic 2 : ", max(arrX))
    print("Ymax Analitic 2 : ", max(arrY))
    print("Waktu total    : ",t,"\n")
CalculationAn2(0.15, 0.0013, 0.01, 50, 35)